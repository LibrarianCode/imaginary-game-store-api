import Server from "./config/api/server";

const server = new Server();
server.loadServer();